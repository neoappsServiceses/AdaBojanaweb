import { Box, Heading, Text, Flex } from "@chakra-ui/react";
import { CurrentWeatherData } from "@mytypes/weather";

interface WeatherHeaderProps {
  data: CurrentWeatherData | undefined;
}

const WeatherHeader: React.FC<WeatherHeaderProps> = ({ data }) => {
  return (
    <Box
      display="flex"
      justifyContent="space-between"
      py="16px"
      px="44px"
      color="white"
      flex="1"
    >
      <Flex direction="column" justifyContent="space-between">
        <Heading as="h1" fontSize="96px" fontWeight="bold">
          Ada Bojana
          <Text fontSize="36px" letterSpacing={1}>
            Montenegro
          </Text>
        </Heading>
        <Flex alignItems="center" mt="20px">
          <Text fontSize="120px" fontWeight="bold">
            {data?.temp_c}°c
          </Text>
        </Flex>
      </Flex>
    </Box>
  );
};

export default WeatherHeader;
