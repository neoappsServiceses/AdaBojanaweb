import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ChakraProvider } from "@chakra-ui/react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Components
import Navbar from "@components/navbar/Navbar";

// Pages
import Home from "./pages/Home";
import Weather from "./pages/Weather";

// Theme
import theme from "./theme";

// Query Client
const queryClient = new QueryClient();

const App: React.FC = () => {
  return (
    <ChakraProvider theme={theme}>
      <Router>
        <div className="App">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route
              path="/weather"
              element={<Weather location="41.862,19.361" />}
            />
          </Routes>
        </div>
      </Router>
    </ChakraProvider>
  );
};

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>
);

export default App;
