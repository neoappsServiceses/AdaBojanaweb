import { Box, Divider, Flex, Text } from "@chakra-ui/react";
import { CurrentWeatherData } from "@mytypes/weather";
import { iconMap } from "@utils/iconMap";
import { FaCloud } from "react-icons/fa";

interface WeatherDetailsProps {
  data: CurrentWeatherData | undefined;
}

const WeatherDetails: React.FC<WeatherDetailsProps> = ({ data }) => {
  const defaultIcon = <FaCloud />;
  const weatherDescription = data?.wx_desc ?? "Sunny";
  const iconElement = iconMap[weatherDescription] || defaultIcon;

  return (
    <Box
      flex="1"
      p={4}
      bg="rgba(38, 77, 120, 0.75)"
      color="white"
      borderRadius="md"
      display="flex"
      flexDirection="column"
    >
      <Text fontSize="xl" mb={4} fontWeight="bold">
        Details
      </Text>
      <Flex
        mb={4}
        flex="1"
        direction={{ base: "column", md: "row" }}
        justify="space-between"
      >
        <Box fontSize="120px" mr={{ base: 0, md: 4 }} mb={{ base: 4, md: 0 }}>
          {iconElement}
        </Box>
        <Flex direction="column" gap={2} flex="1">
          <Text fontSize="lg">RealFeel: {data?.feelslike_c}°C</Text>
          <Divider />
          <Text fontSize="lg">Humidity: {data?.humid_pct}%</Text>
          <Divider />
          <Text fontSize="lg">Visibility: {data?.vis_km} kilometers</Text>
          <Divider />
          <Text fontSize="lg">UV Index: {data?.slp_mb} (Moderate)</Text>
        </Flex>
      </Flex>
    </Box>
  );
};

export default WeatherDetails;
