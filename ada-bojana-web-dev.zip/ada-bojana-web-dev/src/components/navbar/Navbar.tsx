import { Box, Flex, Image, Link, HStack, Spacer } from "@chakra-ui/react";
// import logo from "@assets/logo.png";

const Navbar: React.FC = () => {
  return (
    <Box w="full" p={4} bg="brand.50" boxShadow="md">
      <Flex align="center">
        <Image
          // src={logo}
          alt="logo"
          boxSize="50px"
          objectFit="contain"
        />
        <Spacer />
        <HStack spacing={8} color="brand.eerieBlack" fontWeight="semibold">
          <Link href="/">Home</Link>
          <Link href="/accommodation">Accommodation</Link>
          <Link href="/activities">Activities</Link>
          <Link href="/weather">Weather Forecast</Link>
          <Link href="/contact">Contact</Link>
        </HStack>
      </Flex>
    </Box>
  );
};

export default Navbar;
