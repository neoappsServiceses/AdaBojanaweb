import { CurrentWeatherData } from "@mytypes/types";

export const fetchCurrentWeatherData = async (
  location: string
): Promise<CurrentWeatherData> => {
  const APP_ID = import.meta.env.VITE_WEATHER_API_ID;
  const APP_KEY = import.meta.env.VITE_WEATHER_API_KEY;

  if (!APP_ID || !APP_KEY) {
    throw new Error("API keys are missing");
  }

  const response = await fetch(
    `http://api.weatherunlocked.com/api/current/${location}?app_id=${APP_ID}&app_key=${APP_KEY}`
  );
  if (!response.ok) {
    throw new Error("Network response was not ok");
  }
  return response.json();
};
