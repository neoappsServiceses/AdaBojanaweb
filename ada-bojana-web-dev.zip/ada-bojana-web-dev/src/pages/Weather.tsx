import React from "react";
import { Flex, Spinner, Text } from "@chakra-ui/react";
import { useCurrentWeatherData } from "@hooks/useCurrentWeatherData";
import { useForecastWeatherData } from "@hooks/useForecastWeatherData";

import WeatherHeader from "@components/weather/WeatherHeader";
import HourlyForecast from "@components/weather/HourlyForecast";
import WeatherDetails from "@components/weather/WeatherDetails";
import FiveDayForecast from "@components/weather/FiveDayForecast";

import weatherCover from "@assets/beautiful-cloudscape.jpg";

interface WeatherPageProps {
  location: string;
}

const Weather: React.FC<WeatherPageProps> = ({ location }) => {
  const {
    data: currentWeatherData,
    isLoading: isCurrentWeatherLoading,
    error: currentWeatherError,
  } = useCurrentWeatherData(location);
  const {
    data: forecastWeatherData,
    isLoading: isForecastWeatherLoading,
    error: forecastWeatherError,
  } = useForecastWeatherData(location);

  if (isCurrentWeatherLoading || isForecastWeatherLoading) {
    return (
      <Flex
        direction="column"
        minHeight={`calc(100vh - 82px)`}
        bgImage={`linear-gradient(to top, transparent, black), url(${weatherCover})`}
        bgSize="cover"
        alignItems="center"
        justifyContent="center"
        color="white"
      >
        <Spinner size="xl" />
        <Text mt={4}>Loading...</Text>
      </Flex>
    );
  }

  if (currentWeatherError || forecastWeatherError) {
    return (
      <Flex
        direction="column"
        minHeight={`calc(100vh - 82px)`}
        bgImage={`linear-gradient(to top, transparent, black), url(${weatherCover})`}
        bgSize="cover"
        alignItems="center"
        justifyContent="center"
        color="white"
      >
        <Text>An error occurred while fetching weather data.</Text>
      </Flex>
    );
  }

  return (
    <Flex
      direction="column"
      minHeight={`calc(100vh - 82px)`}
      bgImage={`linear-gradient(to top, transparent, black), url(${weatherCover})`}
      bgSize="cover"
    >
      <WeatherHeader data={currentWeatherData} />
      <Flex direction={{ base: "column", md: "row" }} m={4} gap={4}>
        <HourlyForecast data={forecastWeatherData} />
        <WeatherDetails data={currentWeatherData} />
        <FiveDayForecast data={forecastWeatherData} />
      </Flex>
    </Flex>
  );
};

export default Weather;
