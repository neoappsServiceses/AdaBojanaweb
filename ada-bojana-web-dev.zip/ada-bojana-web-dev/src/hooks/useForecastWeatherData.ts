import { useQuery } from "@tanstack/react-query";
import { fetchForecastWeatherData } from "@api/forecastWeather";
import { ForecastWeatherData } from "../types/weather";

export const useForecastWeatherData = (location: string) => {
  return useQuery<ForecastWeatherData, Error>({
    queryKey: ["ForecastWeatherData", location],
    queryFn: () => fetchForecastWeatherData(location),
  });
};
