import { Box } from "@chakra-ui/react";

const Home = () => {
  return <Box>Home</Box>;
};

export default Home;
