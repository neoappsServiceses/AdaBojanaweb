export interface CurrentWeatherData {
  wx_desc: string;
  wx_icon: string;
  temp_c: number;
  feelslike_c: number;
  humid_pct: number;
  vis_km: number;
  slp_mb: number;
}

export interface ForecastWeatherData {
  Days: {
    date: string;
    Timeframes: {
      date: string;
      time: number;
      wx_desc: string;
      wx_icon: string;
      temp_c: number;
    }[];
  }[];
}
