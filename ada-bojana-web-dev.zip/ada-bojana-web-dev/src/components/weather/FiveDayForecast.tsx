import { Box, Divider, Flex, Text } from "@chakra-ui/react";
import { FaCloud } from "react-icons/fa";
import { iconMap } from "@utils/iconMap";
import { ForecastWeatherData } from "@mytypes/weather";

interface DailyForecastProps {
  data: ForecastWeatherData | undefined;
}

const DailyForecast: React.FC<DailyForecastProps> = ({ data }) => {
  const getFutureDates = (days: number) => {
    const now = new Date();
    return Array.from({ length: days }, (_, i) => {
      const futureDate = new Date();
      futureDate.setDate(now.getDate() + i + 1);
      return futureDate.toISOString().split("T")[0];
    });
  };

  const formatDay = (dateString: string) => {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = { weekday: "long" };
    return date.toLocaleDateString("en-US", options);
  };

  const formatToDMY = (isoDate: string) => {
    const [year, month, day] = isoDate.split("-");
    return `${day}/${month}/${year}`;
  };

  const futureDates = getFutureDates(5);
  const formattedFutureDates = futureDates.map(formatToDMY);

  return (
    <Box
      flex="1"
      p={4}
      bg="rgba(38, 77, 120, 0.75)"
      color="white"
      borderRadius="md"
    >
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        5-Day Forecast
      </Text>
      {futureDates.map((date, index) => {
        const dayData = data?.Days.find(
          (day: { date: string }) => day.date === formattedFutureDates[index]
        );

        const dayWeather = dayData?.Timeframes[0];

        return (
          <Box key={index}>
            <Flex
              direction="row"
              alignItems="center"
              p={2}
              justify="space-between"
            >
              <Text fontSize="md" fontWeight="bold">
                {formatDay(date)}
              </Text>
              <Flex direction="row" align="center">
                <Text fontSize="md" mr={2}>
                  {dayWeather && dayWeather.temp_c !== undefined
                    ? dayWeather.temp_c
                    : "N/A"}
                  °C
                </Text>
                <Box fontSize="30px">
                  {dayWeather ? (
                    iconMap[dayWeather.wx_desc] || <FaCloud />
                  ) : (
                    <FaCloud />
                  )}
                </Box>
              </Flex>
            </Flex>
            {index < futureDates.length - 1 && <Divider />}
          </Box>
        );
      })}
    </Box>
  );
};

export default DailyForecast;
