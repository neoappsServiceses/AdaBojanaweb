import {
  Box,
  Text,
  Flex,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  SimpleGrid,
  Tooltip,
} from "@chakra-ui/react";
import { ForecastWeatherData } from "@mytypes/weather";
import { iconMap } from "@utils/iconMap";
import { FaCloud } from "react-icons/fa";
import { motion } from "framer-motion";
import React from "react";

interface WeatherForecastProps {
  data: ForecastWeatherData | undefined;
}

const MotionFlex = motion(Flex);

const WeatherForecast: React.FC<WeatherForecastProps> = ({ data }) => {
  const formatTime = (time: number) => {
    const hours = Math.floor(time / 100);
    const period = hours >= 12 ? "pm" : "am";
    const adjustedHours = hours % 12 || 12;
    return `${adjustedHours}${period}`;
  };

  const getCurrentDateString = () => {
    const now = new Date();
    const day = now.getDate().toString().padStart(2, "0");
    const month = (now.getMonth() + 1).toString().padStart(2, "0");
    const year = now.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const currentDate = getCurrentDateString();

  const [currentIndex, setCurrentIndex] = React.useState(0);

  const timeframes =
    data?.Days.filter(day => day.date === currentDate).flatMap(
      day => day.Timeframes
    ) || [];

  const visibleTimeframes = timeframes.slice(currentIndex, currentIndex + 4);

  const handleSliderChange = (value: number) => {
    setCurrentIndex(Math.floor(value));
  };

  return (
    <Box
      flex="1"
      p={4}
      bg="rgba(38, 77, 120, 0.75)"
      color="white"
      borderRadius="md"
      overflow="hidden"
      position="relative"
    >
      <Text fontSize="xl" mb={2} fontWeight="bold">
        Hourly Forecast
      </Text>
      <Box overflowX="auto">
        <MotionFlex
          direction="row"
          wrap="nowrap"
          align="center"
          p={2}
          transition={{ duration: 0.5 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <SimpleGrid
            columns={{ base: 1, sm: 2, md: 3, lg: 4 }}
            spacing={4}
            width="100%"
          >
            {visibleTimeframes.map((timeframe, timeframeIndex) => {
              return (
                <Flex
                  key={timeframeIndex}
                  direction="column"
                  alignItems="center"
                  p={2}
                >
                  <Text fontSize="lg" fontWeight="bold" mb={2}>
                    {formatTime(timeframe.time)}
                  </Text>
                  <Box fontSize="40px" mb={2}>
                    {iconMap[timeframe.wx_desc] || <FaCloud />}
                  </Box>
                  <Tooltip
                    label={timeframe.wx_desc}
                    aria-label="Weather description"
                  >
                    <Text
                      fontSize="xs"
                      mb={2}
                      whiteSpace="nowrap"
                      overflow="hidden"
                      textOverflow="ellipsis"
                      maxWidth="100px"
                    >
                      {timeframe.wx_desc}
                    </Text>
                  </Tooltip>
                  <Text fontSize="lg" fontWeight="bold">
                    {timeframe.temp_c}°C
                  </Text>
                </Flex>
              );
            })}
          </SimpleGrid>
        </MotionFlex>
        <Box position="relative" bottom="5%" left="3%" width="95%" zIndex={10}>
          <Slider
            aria-label="slider-ex-1"
            defaultValue={0}
            min={0}
            max={Math.max(0, timeframes.length - 4)}
            onChange={handleSliderChange}
            step={0.01}
            width="100%"
          >
            <SliderTrack>
              <SliderFilledTrack />
            </SliderTrack>
            <SliderThumb />
          </Slider>
        </Box>
      </Box>
    </Box>
  );
};

export default WeatherForecast;
