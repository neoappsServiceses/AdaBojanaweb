import { useQuery } from "@tanstack/react-query";
import { fetchCurrentWeatherData } from "@api/currentWeather";
import { CurrentWeatherData } from "../types/weather";

export const useCurrentWeatherData = (location: string) => {
  return useQuery<CurrentWeatherData, Error>({
    queryKey: ["CurrentWeatherData", location],
    queryFn: () => fetchCurrentWeatherData(location),
  });
};
