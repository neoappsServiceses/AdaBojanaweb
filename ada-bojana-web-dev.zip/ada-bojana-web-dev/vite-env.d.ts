/// <reference types="vite/client" />

interface ImportMetaEnv {
  VITE_WEATHER_API_ID: string;
  VITE_WEATHER_API_KEY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
