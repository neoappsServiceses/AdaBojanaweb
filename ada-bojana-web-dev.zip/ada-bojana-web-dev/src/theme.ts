import { extendTheme, ThemeConfig } from "@chakra-ui/react";

const colors = {
  brand: {
    50: "#f0eaff",
    eerieBlack: "#1b1b1b",
  },
};

const config: ThemeConfig = {
  initialColorMode: "light",
  useSystemColorMode: false,
};

const components = {
  Link: {
    baseStyle: {
      _hover: {
        textDecoration: "underline",
        color: "brand.eerieBlack",
      },
    },
  },
  Text: {
    baseStyle: {
      lineHeight: "110%",
    },
  },
};

const theme = extendTheme({ colors, config, components });

export default theme;
